# BarcodeScanner
BarcodeScanner in Javascript React-Native

Debug Releases :- https://github.com/YoYoJassie/BarcodeScanner/releases/tag/v1.0
the above is debug build, either install  by adb or remove isdebugabble=true to false in androidmanifest and recompile should make it install, make sure install unknown apps is enabled in android os
